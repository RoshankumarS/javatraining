package com.ct.msa.ui;
import com.ct.msa.model.*;
import com.ct.msa.dao.*;
import com.ct.msa.service.*;
import java.util.*;
public class Client {
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("***Welcome to ABC Mobile Shop***");
		System.out.println("================================");
		System.out.println("1.Add Mobile");
		System.out.println("2.Search Mobiles by Id");
		System.out.println("3.Display All Mobiles");
		System.out.println("4.delete mobile");
		System.out.println("5.exit");
		int input = scn.nextInt();
		switch(input) {
		case 1: 
			System.out.println("Enter the name of the mobile");
			String name = scn.nextLine();
			System.out.println("Write the description of the mobile");
			String des = scn.next();
			System.out.println("Enter the id number");
			int id = scn.nextInt();
			System.out.println("Enter the price");
			float price = scn.nextFloat();
			Mobile m = new Mobile(name,des,id,price);
			MobileServiceImpl ms = new MobileServiceImpl();
			ms.addMobile(m);
			break;
		case 2:
			
		}
	}
}
