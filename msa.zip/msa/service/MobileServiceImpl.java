package com.ct.msa.service;

import com.ct.msa.model.Mobile;
import com.ct.msa.dao.*;

public class MobileServiceImpl implements IMobileService {
	static String arr[] = {"Nokia","Asus","Samsung","Vivo","Oppo","Honor","Oneplus","Moto","Motorola"};
	MobileDaoImpl md = new MobileDaoImpl();
	@Override
	public void addMobile(Mobile m) {
        for (String element : arr) {
            if (element.equals(m.getName())) { 
                md.addMobile(m);
            } 
        }
	}

	@Override
	public void deleteMobile(int mId) {
		md.deleteMobile(mId);
		
	}

	@Override
	public void displayAllMobiles(int mId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void searchMobileById(int mId) {
		md.searchMobileById(mId);
		
	}

}
