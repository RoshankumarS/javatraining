package com.ct.msa.dao;

import java.util.*;
import com.ct.msa.model.Mobile;

public class MobileDaoImpl implements IMobileDAO{
	static ArrayList<Mobile> list = new ArrayList<Mobile>();
	
	public void addMobile(Mobile m) {
		list.add(m);
		for (Mobile mob : list) {
			System.out.println(mob.getName() + " " + mob.getDescription() + " " + mob.getId() + " " + mob.getPrice());
		}
	}

	public void deleteMobile(int mId) {
		Iterator<Mobile> i = list.iterator();
		while (i.hasNext()) {
			System.out.println(i.next().getId());
			if(mId == i.next().getId()) {
		    i.remove();
			}
		}
	}

	
	public void displayAllMobiles(int mId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void searchMobileById(int mId) {
		for(Mobile mob : list) {
			if (mob.getId() == mId) {
				System.out.println(mob.getName() + " " + mob.getDescription() + " " + mob.getId() + " " + mob.getPrice());
			}
		}
		
	}

}
